// ============================================================
// SplitWay — Node.js Server
// Обрабатывает push-уведомления через web-push
// ============================================================

require('dotenv').config();
const express = require('express');
const cors    = require('cors');
const webpush = require('web-push');
const path    = require('path');

const app  = express();
const PORT = process.env.PORT || 3000;

// ---- Middleware ----
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ---- VAPID ----
if (process.env.VAPID_PUBLIC_KEY && process.env.VAPID_PRIVATE_KEY) {
  webpush.setVapidDetails(
    process.env.VAPID_SUBJECT || 'mailto:admin@splitway.app',
    process.env.VAPID_PUBLIC_KEY,
    process.env.VAPID_PRIVATE_KEY
  );
  console.log('✅ VAPID configured');
} else {
  console.warn('⚠️  VAPID keys not set — push notifications disabled');
}

// ---- Routes ----

// VAPID public key для клиента
app.get('/api/vapid-public-key', (req, res) => {
  res.json({ key: process.env.VAPID_PUBLIC_KEY || null });
});

// Отправить push всем подписчикам поездки
app.post('/api/push/send', async (req, res) => {
  const { subscriptions, payload } = req.body;
  if (!subscriptions?.length) return res.json({ sent: 0 });

  const results = await Promise.allSettled(
    subscriptions.map(sub =>
      webpush.sendNotification(
        { endpoint: sub.endpoint, keys: { p256dh: sub.p256dh, auth: sub.auth } },
        JSON.stringify(payload)
      )
    )
  );

  const sent = results.filter(r => r.status === 'fulfilled').length;
  const failed = results.length - sent;
  console.log(`Push: ${sent} sent, ${failed} failed`);
  res.json({ sent, failed });
});

// SPA fallback
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`\n🚀 SplitWay server running at http://localhost:${PORT}`);
  console.log(`   Open http://localhost:${PORT} in your browser\n`);
});
