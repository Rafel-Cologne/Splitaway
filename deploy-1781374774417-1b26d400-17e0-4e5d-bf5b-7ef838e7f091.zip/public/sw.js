// ============================================================
// SplitWay — Service Worker v1.7
// Офлайн-кэш + Push-уведомления
// ============================================================

const CACHE_NAME = 'splitway-v1.7';
const OFFLINE_URL = '/offline.html';

// HTML-файлы НИКОГДА не кэшируются — всегда свежие с сервера
const NO_CACHE_PATTERNS = [
  /\/index\.html/,
  /\/$/,
  /\/js\//,
];

const STATIC_ASSETS = [
  '/offline.html',
  '/manifest.json',
  'https://fonts.googleapis.com/css2?family=Sora:wght@300;400;500;600;700&family=DM+Mono:wght@400;500&display=swap',
  'https://unpkg.com/lucide@latest/dist/umd/lucide.js'
];

// ---- Install ----
self.addEventListener('install', event => {
  console.log('[SW] Installing v1.6...');
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      return cache.addAll(STATIC_ASSETS.map(url => new Request(url, { mode: 'no-cors' })))
        .catch(err => console.warn('[SW] Cache partial fail:', err));
    }).then(() => self.skipWaiting())
  );
});

// ---- Activate — удаляем ВСЕ старые кэши ----
self.addEventListener('activate', event => {
  console.log('[SW] Activating v1.6...');
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.map(k => {
        console.log('[SW] Deleting old cache:', k);
        return caches.delete(k);
      }))
    ).then(() => self.clients.claim())
  );
});

// ---- Fetch ----
self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET') return;
  if (event.request.url.includes('supabase.co')) return;
  if (event.request.url.includes('/api/push/')) return;
  if (event.request.url.includes('anthropic.com')) return;
  if (event.request.url.includes('googleapis.com')) return;

  const url = new URL(event.request.url);
  const isHtmlOrScript = NO_CACHE_PATTERNS.some(p => p.test(url.pathname));

  if (isHtmlOrScript) {
    // HTML и JS — всегда с сети, без кэша
    event.respondWith(
      fetch(event.request, { cache: 'no-store' })
        .catch(() => {
          if (event.request.headers.get('accept')?.includes('text/html')) {
            return caches.match(OFFLINE_URL);
          }
        })
    );
    return;
  }

  // Остальное (иконки, шрифты) — network-first с кэшем
  event.respondWith(
    fetch(event.request)
      .then(response => {
        if (response.ok) {
          const clone = response.clone();
          caches.open(CACHE_NAME).then(c => c.put(event.request, clone));
        }
        return response;
      })
      .catch(() => caches.match(event.request))
  );
});

// ---- Push Notifications ----
self.addEventListener('push', event => {
  let data = { title: 'SplitWay', body: 'Новое обновление в поездке', icon: '/icons/icon-192.png' };
  try { data = { ...data, ...event.data.json() }; } catch(e) {}

  event.waitUntil(
    self.registration.showNotification(data.title, {
      body:    data.body,
      icon:    data.icon || '/icons/icon-192.png',
      badge:   '/icons/icon-72.png',
      tag:     data.tag || 'splitway',
      data:    data.url ? { url: data.url } : {},
      actions: data.actions || [
        { action: 'open',    title: '👁 Открыть' },
        { action: 'dismiss', title: '✕ Закрыть'  }
      ],
      vibrate:    [200, 100, 200],
      requireInteraction: false
    })
  );
});

// ---- Notification Click ----
self.addEventListener('notificationclick', event => {
  event.notification.close();
  if (event.action === 'dismiss') return;

  const url = event.notification.data?.url || '/';
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true })
      .then(clients => {
        const existing = clients.find(c => c.url.includes(self.location.origin));
        if (existing) { existing.focus(); existing.navigate(url); }
        else self.clients.openWindow(url);
      })
  );
});

// ---- Background Sync ----
self.addEventListener('sync', event => {
  if (event.tag === 'sync-expenses') {
    event.waitUntil(syncPendingExpenses());
  }
});

async function syncPendingExpenses() {
  console.log('[SW] Background sync: expenses');
}
